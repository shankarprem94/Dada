﻿using ADO_Proj.BO;
using ADO_Proj.DL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO_Proj.BL
{
    public class EmployeeBL
    {
        public int AddEmployee(Employee emp)
        {
            try
            {
                var _objDb = new DbEmployee();
                var id = _objDb.AddEmployee(emp);
                return id;
            }
            catch (Exception ex)
            {
                throw new Exception("Emp:AddEmployee() - " + ex.Message);
            }
        }

        public Employee GetEmployeeDetails(int id)
        {
            try
            {
                var _objDb = new DbEmployee();
                var stDetails = _objDb.GetEmployeeDetails(id);
                return stDetails;
            }
            catch (Exception ex)
            {
                throw new Exception("Emp:GetEmployeeDetails() - " + ex.Message);
            }
        }

        public IEnumerable<Employee> GetEmployeeList(int id)
        {
            try
            {
                var _objDb = new DbEmployee();
                var stDetailsList = _objDb.GetEmployeeList(id);
                return stDetailsList;
            }
            catch (Exception ex)
            {
                throw new Exception("Emp:GetEmployeeList() - " + ex.Message);
            }
        }

        public bool UpdateEmployee(Employee emp)
        {
            try
            {
                var _objDb = new DbEmployee();
                var flag = _objDb.UpdateEmployee(emp);
                return flag;
            }
            catch (Exception ex)
            {
                throw new Exception("Emp:UpdateEmployee() - " + ex.Message);
            }
        }
    }
}
