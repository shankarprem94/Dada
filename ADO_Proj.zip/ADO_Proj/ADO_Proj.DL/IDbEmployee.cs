﻿
using ADO.Proj.BO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO_Proj.DL
{
    public interface IDbEmployee
    {
        int AddEmployee(Employee emp);
        bool UpdateEmployee(Employee emp);
        Employee GetEmployeeDetails(int id);
        IEnumerable<Employee> GetEmployeeList(int id);
    }
}
