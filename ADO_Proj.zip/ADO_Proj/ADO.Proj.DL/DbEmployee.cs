﻿using ADO.Proj.BO;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADO.Proj.DL
{
    public class DbEmployee : IDbEmployee
    {
        public static string ConnectionString = ConfigurationManager.ConnectionStrings["EmployeeConnection"].ToString();

        public int AddEmployee(Employee emp)
        {
            try
            {
                int id = 0;
                using (SqlConnection conn = new SqlConnection(ConnectionString))
                {
                    using (SqlCommand myCommand = new SqlCommand("EM_ADD_EMPLOYEE", conn))
                    {
                        myCommand.CommandType = CommandType.StoredProcedure;
                        myCommand.Parameters.Add("@NAME", SqlDbType.VarChar).Value = emp.Name;
                        myCommand.Parameters.Add("@EMAIL", SqlDbType.VarChar).Value = emp.Email;
                        myCommand.Parameters.Add("@MOBILE", SqlDbType.VarChar).Value = emp.Mobile;
                        myCommand.Parameters.Add("@ADDRESS", SqlDbType.VarChar).Value = emp.Address;
                        myCommand.Parameters.Add("@ID", SqlDbType.Int).Direction = ParameterDirection.Output;
                        conn.Open();
                        myCommand.ExecuteNonQuery();
                        id = (int)myCommand.Parameters["@ID"].Value;
                        conn.Close();
                    }
                }
                return id;
            }
            catch (Exception ex)
            {
                throw new Exception("Emp.DL:AddEmployee() -" + ex.ToString());
            }
        }

        public Employee GetEmployeeDetails(int id)
        {
            try
            {
                var objEmp = new Employee();
                using (SqlConnection conn = new SqlConnection(ConnectionString))
                {
                    using (SqlCommand myCommand = new SqlCommand("EM_EMPLOYEE_DETAILS", conn))
                    {
                        myCommand.CommandType = CommandType.StoredProcedure;
                        myCommand.Parameters.Add("@ID", SqlDbType.Int).Value = id;
                        conn.Open();
                        using (SqlDataReader dataReader = myCommand.ExecuteReader())
                        {
                            dataReader.Read();
                            objEmp.ID = (int)dataReader["ID"];
                            objEmp.Name = (string)dataReader["NAME"];
                            objEmp.Email = (string)dataReader["EMAIL"];
                            objEmp.Mobile = (string)dataReader["MOBILE"];
                            objEmp.Address = (string)dataReader["ADDRESS"];
                        }
                    }
                }
                return objEmp;
            }
            catch (Exception ex)
            {
                throw new Exception("Emp.DL:GetEmployeeDetails() -" + ex.ToString());
            }
        }

        public IEnumerable<Employee> GetEmployeeList()
        {
            try
            {
                var objEmpList = new List<Employee>();
                using (SqlConnection conn = new SqlConnection(ConnectionString))
                {
                    using (SqlCommand myCommand = new SqlCommand("EM_EMPLOYEE_LIST", conn))
                    {
                        myCommand.CommandType = CommandType.StoredProcedure;
                        conn.Open();
                        using (SqlDataReader dataReader = myCommand.ExecuteReader())
                        {
                            while (dataReader.Read())
                            {
                                var objEmp = new Employee
                                {
                                    ID = (int)dataReader["ID"],
                                    Name = (string)dataReader["NAME"],
                                    Email = (string)dataReader["EMAIL"],
                                    Mobile = (string)dataReader["MOBILE"],
                                    Address = (string)dataReader["ADDRESS"]
                                };
                                objEmpList.Add(objEmp);
                            }
                        }
                    }
                }
                return objEmpList;
            }
            catch (Exception ex)
            {
                throw new Exception("Emp.DL:GetEmployeeList() -" + ex.ToString());
            }
        }

        public bool UpdateEmployee(Employee emp)
        {
            bool flag;
            try
            {
                using (SqlConnection conn = new SqlConnection(ConnectionString))
                {
                    using (SqlCommand myCommand = new SqlCommand("EM_UPDATE_EMPLOYEE", conn))
                    {
                        myCommand.CommandType = CommandType.StoredProcedure;
                        myCommand.Parameters.Add("@ID", SqlDbType.Int).Value = emp.ID;
                        myCommand.Parameters.Add("@NAME", SqlDbType.VarChar).Value = emp.Name;
                        myCommand.Parameters.Add("@EMAIL", SqlDbType.VarChar).Value = emp.Email;
                        myCommand.Parameters.Add("@MOBILE", SqlDbType.VarChar).Value = emp.Mobile;
                        myCommand.Parameters.Add("@ADDRESS", SqlDbType.VarChar).Value = emp.Address;
                        conn.Open();
                        myCommand.ExecuteNonQuery();
                        conn.Close();
                    }
                }
                flag = true;
            }
            catch (Exception ex)
            {
                throw new Exception("Emp.DL:UpdateEmployee() -" + ex.ToString());
            }
            return flag;
        }


    }
}
