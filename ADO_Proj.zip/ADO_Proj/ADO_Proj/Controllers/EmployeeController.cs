﻿using ADO.Proj.BL;
using ADO.Proj.BO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ADO_Proj.Web.Controllers
{
    public class EmployeeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public JsonResult GetAllEmployee()
        {
            IEnumerable<Employee> lst = new List<Employee>();
            int Count = 0;

            try
            {
                EmployeeBL obj = new EmployeeBL();
                lst = obj.GetEmployeeList();
                Count = lst.Count();
            }
            catch (Exception ex)
            {
                Response.Write(ex);
            }
            var objFac = lst.Select(s => new
            {
                id = s.ID,
                name = s.Name,
                email = s.Email,
                mobile = s.Mobile,
                address = s.Address
            });
            return Json(new { draw = 1, recordsTotal = Count, recordsFiltered = 10, data = objFac }, JsonRequestBehavior.AllowGet);
        }
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Employee emp)
        {
            try
            {
                if (!ModelState.IsValid)
                    return View();
                EmployeeBL objEmp = new EmployeeBL();
                int id = objEmp.AddEmployee(emp);
                if (id > 0)
                {
                    ViewBag.Status = id;
                    ModelState.Clear();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return View();
        }

        [HttpGet]
        public ActionResult Edit(int Id)
        {
            Employee ob = new Employee();
            try
            {
                EmployeeBL obj = new EmployeeBL();
                ob = obj.GetEmployeeDetails(Id);
            }
            catch (Exception ex)
            {
                Response.Write(ex);
            }
            return View(ob);
        }
        [HttpPost]
        public ActionResult Edit(Employee ob)
        {
            ViewBag.Status = 1;

            try
            {
                if (!ModelState.IsValid)
                    return View(ob);

                EmployeeBL objBl = new EmployeeBL();
                bool flag = objBl.UpdateEmployee(ob);
                if (flag == true)
                {
                    ModelState.Clear();
                    return Redirect(Url.Content("~/employee"));
                }
            }
            catch (Exception ex)
            {
                ViewBag.Status = 0;
                Response.Write(ex);
            }
            return View();
        }
    }
}